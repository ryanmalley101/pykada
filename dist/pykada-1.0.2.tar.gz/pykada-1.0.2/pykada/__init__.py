"""Pykada - A Python client for the Verkada API."""

__version__ = "1.0.2"